// gcc chall.c -o chall -no-pie -fno-stack-protector

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#define RATING 0
#define SALDO 1
#define MAX_INT ((unsigned int)pow(2,31)-1)

struct kebab_amigo_t{
	char nombre[0x20];
	int rating;
	int saldo_caja;
	void (*destructor)();
} kebab_amigo;

void _cerrar_restaurante()
{
	puts("Estaba bueno eh, pero te has pasado con el rating.");
	exit(0);
}

void _abrir_restaurante()
{
	setvbuf(stdin,  NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	strncpy(kebab_amigo.nombre, "PwnKebab", 0x20);
	kebab_amigo.rating = 0;
	kebab_amigo.saldo_caja = 0;
	kebab_amigo.destructor = &_cerrar_restaurante;
}

int _read_int(){
	printf("> ");

	int opt = 0;
	scanf("%d", &opt);
	
	return opt;
}

int _menu()
{
	puts("Elige algo del menu:");
	puts("\t1. Kebab mixto");
	puts("\t2. Durum mixto");
	puts("\t3. Kebab falafel");
	puts("\t4. Durum doble con queso");
	puts("\t5. Baklava");
	
	return _read_int();
}

int check(int n, int flags){
	if (flags == RATING && kebab_amigo.rating+n >= 0)
		return 1;

	if (flags == SALDO && kebab_amigo.saldo_caja+n >= 0)
		return 1;

	puts("Uy, q intentas?");
	return 0;
}

void kebab_mixto()
{
	puts("Que rico, encima mixto!");
	if (check(3, SALDO))
		kebab_amigo.saldo_caja += 3;
	
	puts("Que rating le das?");
	int _rating = _read_int();
	if (check(_rating, RATING))
		kebab_amigo.rating += _rating;
}

void durum_mixto()
{
	puts("Que rico, encima durum!");
	if (check(4, SALDO))
		kebab_amigo.saldo_caja += 4;
	
	puts("Que rating le das?");
	int _rating = _read_int();
	if (check(_rating, RATING))
		kebab_amigo.rating += _rating;
}

void kebab_falafel()
{
	puts("Que rico, encima falafel!");
	if (check(3, SALDO))
		kebab_amigo.saldo_caja += 3;
	
	puts("Que rating le das?");
	int _rating = _read_int();
	if (check(_rating, RATING))
		kebab_amigo.rating += _rating;
}

void durum_doble()
{
	puts("Boooof, encima doble chaval!");
	if (check(5, SALDO))
		kebab_amigo.saldo_caja += 5;
	
	puts("Que rating le das?");
	int _rating = _read_int();
	if (check(_rating, RATING)){
		puts("Bueno, pues se duplica por ser doble 😎");
		kebab_amigo.rating += (_rating*2);
	}
}

void baklava()
{
	puts("Toma un baklava gratis, encima gratis!");
	puts("Por si quieres dejar propina amigo: ");

	scanf("%ld", &kebab_amigo.saldo_caja);
}

void banhos_turcos(){
	char respuesta[100];
	puts("Que haces aqui amigo? Esto es solo para empleados!!");
	read(0, respuesta, 0x100);
}

int main(int argc, char const *argv[])
{
	_abrir_restaurante();
	printf("-- Bienvenido a %s --", kebab_amigo.nombre);
	while(1){
		switch(_menu()){
			case 1:
				kebab_mixto(); break;
			case 2:
				durum_mixto(); break;
			case 3:
				kebab_falafel(); break;
			case 4:
				durum_doble(); break;
			case 5:
				baklava(); break;
			default: exit(1);
		}
		if((unsigned int)kebab_amigo.rating > MAX_INT){
			kebab_amigo.destructor();
		}
	}
	return 0;
}
